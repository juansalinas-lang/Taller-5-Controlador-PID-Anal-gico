R = 5 % Resistencia 
L = 0.1 % Inductancia 
C = 220e-6 % Capacitancia 
 

num=[1/(L*C)];
den=[1, R/L, 1/(L*C)]

%kc=8.44670553562182;

kp=10;
ki=1000;
kd=0.05;
kc=8.44670553562182;

%%segunda parte
%kp=kc;
%ki=626.991258675136;
%kd=0.0200924249696484;

Gs = tf(num,den)

